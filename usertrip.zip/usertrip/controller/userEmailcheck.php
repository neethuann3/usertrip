<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
include('../model/usermodel.php');

    $email = $_POST['email'];
     $user = new users();
    //check email id unique or not 
    $checkemailexist = $user->emailcheck($email);
  if($checkemailexist>0){
      echo "Sorry! email has already taken. Please try another.";
  }
?>
