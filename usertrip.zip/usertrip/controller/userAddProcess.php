<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
include('../model/usermodel.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    addUser();
}

function addUser() {
    /*echo "<pre>";
    print_r($_POST);exit;*/
    session_start();
    $_SESSION['emailexist'] = 0;
    $user = new users();
    $email = $_POST['usermail'];
    //check email id unique or not 
    $checkemailexist = $user->emailcheck($email);
    if ($checkemailexist == 0) {
        $listUsers = $user->AddUsers();
        header('location:../view/success.php');
    } else {
        
        $_SESSION['emailexist'] = 1;
        header('location:../view/Adduser.php');
    }
}

?>
