<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
header('location:view/Adduser.php'); // set default page 
//echo "fgghgh";
?>
