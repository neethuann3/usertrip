<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
include('../config.php');
class users{
    
     function __construct(){
        $con = new DB();
    }

    public function ListUserDetails()
    {
     $query=mysql_query("select * from user_entry");
     return $query;
    }
   
    public function AddUsers()
    {
       // print_r($_POST);exit;
        $favfood=implode(",",$_POST['food']);
         $visitedstate=implode(",",$_POST['states']);
        $statevisited=implode(",",$_POST['states']);
      $sql="insert into user_entry(`user_name`,`user_email`,`user_country`,`user_rating`,`user_fav_food`,`user_state_visited`)values('".$_POST['username']."','".$_POST['usermail']."','".$_POST['country']."','".$_POST['rating']."','".$favfood."','".$statevisited."')";
   //  print_r($sql);exit;
      $query=mysql_query($sql);
      return true;
      }
      
      public function emailcheck($email)
      {
        
      $sql="select count(*)as count from user_entry where `user_email`='".$email."'"; 
       $result=mysql_query($sql);
       $countmail= mysql_fetch_array($result);
       return $countmail['count'];
      }
      
    }

?>
